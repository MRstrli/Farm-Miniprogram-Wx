// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init({
  env: 'cloud1-9gpnbsunc739e36a' // 表示在当前环境中初始化云函数
})

// 云函数入口函数
exports.main = async (event, context) => {
  // 获取基础信息
  const wxContext = cloud.getWXContext()

  return {
    openid: wxContext.OPENID,
    // 如果需要，可以返回更多信息
    appid: wxContext.APPID,
    unionid: wxContext.UNIONID
  }
}

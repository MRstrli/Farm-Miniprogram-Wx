// 云函数入口文件
const cloud = require('wx-server-sdk')
cloud.init({
  traceUser: true,
  env: 'cloud1-9gpnbsunc739e36a'
})

const crypto = require('crypto');


exports.main = async (event, context) => {
  const { data } = event;
  const hash = crypto.createHash('sha256');
  hash.update(data);
  return hash.digest('hex');
};

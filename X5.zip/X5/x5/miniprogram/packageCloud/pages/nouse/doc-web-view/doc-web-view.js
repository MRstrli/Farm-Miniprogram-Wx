Page({
  onShareAppMessage() {
    return {
      title: '小程序云开发文档',
      path: 'packageCloud/pages/doc-web-view/doc-web-view'
    }
  },
})

import CustomPage from '../../../base/CustomPage'

CustomPage({
  onShareAppMessage() {
    return {
      title: 'loadmore',
      path: 'packageExtend/pages/base/loadmore/loadmore'
    }
  },
})

import CustomPage from '../../../base/CustomPage'

CustomPage({
  onShareAppMessage() {
    return {
      title: 'badge',
      path: 'packageExtend/pages/base/badge/badge'
    }
  },
})

import CustomPage from '../../../base/CustomPage'

CustomPage({
  onShareAppMessage() {
    return {
      title: 'flex',
      path: 'packageExtend/pages/base/flex/flex'
    }
  },
})

const envList = [{"envId":"cloud1-9gpnbsunc739e36a","alias":"cloud1"}]
const isMac = false
module.exports = {
    envList,
    isMac
}
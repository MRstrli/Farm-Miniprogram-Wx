Page({
  data: {
    // 页面的初始数据
  },

  goToUserManagement: function() {
    wx.navigateTo({
      url: 'page/admin/UserManagement/UserManagement'
    });
  },
  goToOrderManagement: function() {
    wx.navigateTo({
      url: 'page/admin/OrderManagement/OrderManagement'
    });
  },
  goToApplicationManagement: function() {
    wx.navigateTo({
      url: 'page/admin/ApplicationManagement/ApplicationManagement'
    });
  },


  onLoad: function(options) {
    
  },
  onShow: function() {
    // 页面显示时执行
  },
  onHide: function() {
    // 页面隐藏时执行
  },
  onUnload: function() {
    // 页面卸载时执行
  }
});

const db = wx.cloud.database(); // 初始化云数据库
Page({
  data: {
    order_id: '',
    order: {},
  },

  onLoad: function(options) {
    // 获取传入的订单信息
    this.setData({
      order_id: options.id
    });
    console.log(this.data.order_id);
    this.fetchOrderData();
  },

  fetchOrderData: function() {
    db.collection('orders').doc(this.data.order_id).get({
      success: res => {
        this.setData({
          order: res.data
        });
      },
      fail: err => {
        wx.showToast({
          icon: 'none',
          title: '获取数据失败'
        });
        console.error('获取订单数据失败：', err);
      }
    });
  },

  submitForm: function(e) {
    const formData = e.detail.value;
    console.log('Form data:', formData);


    db.collection('orders').doc(this.data.order_id).update({
      data: {
        orderNumber: formData.orderNumber,
        customerID: formData.customerID,
        farmerID: formData.farmerID,
        goodname: formData.goodname,
        price: formData.price,
        num: formData.num,
        note: formData.note,
        Farmconfirm: formData.Farmconfirm === 'true',
        isPaid: formData.isPaid === 'true'
      },
      success: function(res) {
        wx.showToast({
          title: '更新成功',
          icon: 'success',
          duration: 2000,
          complete: function() {
            wx.navigateBack();
          }
        });
      },
      fail: console.error
    });
  }
});
